﻿namespace ConverterApp
{
    partial class frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_UofM = new System.Windows.Forms.Label();
            this.txt_UnitOfMeasure = new System.Windows.Forms.TextBox();
            this.btn_CM_to_Inches = new System.Windows.Forms.Button();
            this.btn_M_to_Feet = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_cels_to_fahr = new System.Windows.Forms.Button();
            this.btn_cm_to_feet = new System.Windows.Forms.Button();
            this.btn_km_to_miles = new System.Windows.Forms.Button();
            this.clear_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.saved_txt = new System.Windows.Forms.Label();
            this.listStatus = new System.Windows.Forms.Label();
            this.item1 = new System.Windows.Forms.TextBox();
            this.item5 = new System.Windows.Forms.TextBox();
            this.item4 = new System.Windows.Forms.TextBox();
            this.item3 = new System.Windows.Forms.TextBox();
            this.item2 = new System.Windows.Forms.TextBox();
            this.measurement1 = new System.Windows.Forms.Label();
            this.to1 = new System.Windows.Forms.TextBox();
            this.convert1 = new System.Windows.Forms.Label();
            this.to5 = new System.Windows.Forms.TextBox();
            this.to4 = new System.Windows.Forms.TextBox();
            this.to3 = new System.Windows.Forms.TextBox();
            this.to2 = new System.Windows.Forms.TextBox();
            this.convert2 = new System.Windows.Forms.Label();
            this.convert3 = new System.Windows.Forms.Label();
            this.convert4 = new System.Windows.Forms.Label();
            this.convert5 = new System.Windows.Forms.Label();
            this.measurement2 = new System.Windows.Forms.Label();
            this.measurement3 = new System.Windows.Forms.Label();
            this.measurement4 = new System.Windows.Forms.Label();
            this.measurement5 = new System.Windows.Forms.Label();
            this.txt_Convert = new System.Windows.Forms.TextBox();
            this.unit = new System.Windows.Forms.Label();
            this.convertsTo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_UofM
            // 
            this.lbl_UofM.AutoSize = true;
            this.lbl_UofM.Location = new System.Drawing.Point(11, 20);
            this.lbl_UofM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_UofM.Name = "lbl_UofM";
            this.lbl_UofM.Size = new System.Drawing.Size(108, 13);
            this.lbl_UofM.TabIndex = 0;
            this.lbl_UofM.Text = "Unit of Measurement:";
            // 
            // txt_UnitOfMeasure
            // 
            this.txt_UnitOfMeasure.Location = new System.Drawing.Point(123, 17);
            this.txt_UnitOfMeasure.Margin = new System.Windows.Forms.Padding(2);
            this.txt_UnitOfMeasure.Name = "txt_UnitOfMeasure";
            this.txt_UnitOfMeasure.Size = new System.Drawing.Size(76, 20);
            this.txt_UnitOfMeasure.TabIndex = 1;
            // 
            // btn_CM_to_Inches
            // 
            this.btn_CM_to_Inches.Location = new System.Drawing.Point(66, 50);
            this.btn_CM_to_Inches.Margin = new System.Windows.Forms.Padding(2);
            this.btn_CM_to_Inches.Name = "btn_CM_to_Inches";
            this.btn_CM_to_Inches.Size = new System.Drawing.Size(122, 19);
            this.btn_CM_to_Inches.TabIndex = 2;
            this.btn_CM_to_Inches.Text = "Centimetres to Inches";
            this.btn_CM_to_Inches.UseVisualStyleBackColor = true;
            this.btn_CM_to_Inches.Click += new System.EventHandler(this.btn_CM_to_Inches_Click);
            // 
            // btn_M_to_Feet
            // 
            this.btn_M_to_Feet.Location = new System.Drawing.Point(66, 85);
            this.btn_M_to_Feet.Margin = new System.Windows.Forms.Padding(2);
            this.btn_M_to_Feet.Name = "btn_M_to_Feet";
            this.btn_M_to_Feet.Size = new System.Drawing.Size(122, 19);
            this.btn_M_to_Feet.TabIndex = 3;
            this.btn_M_to_Feet.Text = "Metres to Feet";
            this.btn_M_to_Feet.UseVisualStyleBackColor = true;
            this.btn_M_to_Feet.Click += new System.EventHandler(this.btn_M_to_Feet_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(240, 414);
            this.btn_Exit.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(56, 23);
            this.btn_Exit.TabIndex = 4;
            this.btn_Exit.Text = "EXIT";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_cels_to_fahr
            // 
            this.btn_cels_to_fahr.Location = new System.Drawing.Point(66, 120);
            this.btn_cels_to_fahr.Margin = new System.Windows.Forms.Padding(2);
            this.btn_cels_to_fahr.Name = "btn_cels_to_fahr";
            this.btn_cels_to_fahr.Size = new System.Drawing.Size(122, 19);
            this.btn_cels_to_fahr.TabIndex = 8;
            this.btn_cels_to_fahr.Text = "Celsius to Fahrenheit";
            this.btn_cels_to_fahr.UseVisualStyleBackColor = true;
            this.btn_cels_to_fahr.Click += new System.EventHandler(this.btn_cels_to_fahr_Click);
            // 
            // btn_cm_to_feet
            // 
            this.btn_cm_to_feet.Location = new System.Drawing.Point(66, 155);
            this.btn_cm_to_feet.Margin = new System.Windows.Forms.Padding(2);
            this.btn_cm_to_feet.Name = "btn_cm_to_feet";
            this.btn_cm_to_feet.Size = new System.Drawing.Size(122, 19);
            this.btn_cm_to_feet.TabIndex = 9;
            this.btn_cm_to_feet.Text = "Centimetres to Feet";
            this.btn_cm_to_feet.UseVisualStyleBackColor = true;
            this.btn_cm_to_feet.Click += new System.EventHandler(this.btn_cm_to_feet_Click);
            // 
            // btn_km_to_miles
            // 
            this.btn_km_to_miles.Location = new System.Drawing.Point(66, 190);
            this.btn_km_to_miles.Margin = new System.Windows.Forms.Padding(2);
            this.btn_km_to_miles.Name = "btn_km_to_miles";
            this.btn_km_to_miles.Size = new System.Drawing.Size(122, 19);
            this.btn_km_to_miles.TabIndex = 10;
            this.btn_km_to_miles.Text = "Kilometres to Miles";
            this.btn_km_to_miles.UseVisualStyleBackColor = true;
            this.btn_km_to_miles.Click += new System.EventHandler(this.btn_km_to_miles_Click);
            // 
            // clear_btn
            // 
            this.clear_btn.Location = new System.Drawing.Point(123, 414);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(113, 23);
            this.clear_btn.TabIndex = 12;
            this.clear_btn.Text = "Clear saved inputs";
            this.clear_btn.UseVisualStyleBackColor = true;
            this.clear_btn.Click += new System.EventHandler(this.clear_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.Location = new System.Drawing.Point(212, 101);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(87, 56);
            this.save_btn.TabIndex = 13;
            this.save_btn.Text = "Save Unit of Measurement";
            this.save_btn.UseVisualStyleBackColor = true;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // saved_txt
            // 
            this.saved_txt.AutoSize = true;
            this.saved_txt.Location = new System.Drawing.Point(206, 158);
            this.saved_txt.Name = "saved_txt";
            this.saved_txt.Size = new System.Drawing.Size(0, 13);
            this.saved_txt.TabIndex = 15;
            // 
            // listStatus
            // 
            this.listStatus.AutoSize = true;
            this.listStatus.Location = new System.Drawing.Point(11, 447);
            this.listStatus.Name = "listStatus";
            this.listStatus.Size = new System.Drawing.Size(0, 13);
            this.listStatus.TabIndex = 18;
            // 
            // item1
            // 
            this.item1.Location = new System.Drawing.Point(14, 269);
            this.item1.Name = "item1";
            this.item1.ReadOnly = true;
            this.item1.Size = new System.Drawing.Size(63, 20);
            this.item1.TabIndex = 19;
            // 
            // item5
            // 
            this.item5.Location = new System.Drawing.Point(14, 373);
            this.item5.Name = "item5";
            this.item5.ReadOnly = true;
            this.item5.Size = new System.Drawing.Size(63, 20);
            this.item5.TabIndex = 20;
            // 
            // item4
            // 
            this.item4.Location = new System.Drawing.Point(14, 347);
            this.item4.Name = "item4";
            this.item4.ReadOnly = true;
            this.item4.Size = new System.Drawing.Size(63, 20);
            this.item4.TabIndex = 21;
            // 
            // item3
            // 
            this.item3.Location = new System.Drawing.Point(14, 321);
            this.item3.Name = "item3";
            this.item3.ReadOnly = true;
            this.item3.Size = new System.Drawing.Size(63, 20);
            this.item3.TabIndex = 22;
            // 
            // item2
            // 
            this.item2.Location = new System.Drawing.Point(14, 295);
            this.item2.Name = "item2";
            this.item2.ReadOnly = true;
            this.item2.Size = new System.Drawing.Size(63, 20);
            this.item2.TabIndex = 23;
            // 
            // measurement1
            // 
            this.measurement1.AutoSize = true;
            this.measurement1.Location = new System.Drawing.Point(83, 272);
            this.measurement1.Name = "measurement1";
            this.measurement1.Size = new System.Drawing.Size(0, 13);
            this.measurement1.TabIndex = 25;
            // 
            // to1
            // 
            this.to1.Location = new System.Drawing.Point(209, 269);
            this.to1.Name = "to1";
            this.to1.ReadOnly = true;
            this.to1.Size = new System.Drawing.Size(63, 20);
            this.to1.TabIndex = 26;
            // 
            // convert1
            // 
            this.convert1.AutoSize = true;
            this.convert1.Location = new System.Drawing.Point(278, 272);
            this.convert1.Name = "convert1";
            this.convert1.Size = new System.Drawing.Size(0, 13);
            this.convert1.TabIndex = 27;
            // 
            // to5
            // 
            this.to5.Location = new System.Drawing.Point(209, 373);
            this.to5.Name = "to5";
            this.to5.ReadOnly = true;
            this.to5.Size = new System.Drawing.Size(63, 20);
            this.to5.TabIndex = 28;
            // 
            // to4
            // 
            this.to4.Location = new System.Drawing.Point(209, 347);
            this.to4.Name = "to4";
            this.to4.ReadOnly = true;
            this.to4.Size = new System.Drawing.Size(63, 20);
            this.to4.TabIndex = 29;
            // 
            // to3
            // 
            this.to3.Location = new System.Drawing.Point(209, 321);
            this.to3.Name = "to3";
            this.to3.ReadOnly = true;
            this.to3.Size = new System.Drawing.Size(63, 20);
            this.to3.TabIndex = 30;
            // 
            // to2
            // 
            this.to2.Location = new System.Drawing.Point(209, 295);
            this.to2.Name = "to2";
            this.to2.ReadOnly = true;
            this.to2.Size = new System.Drawing.Size(63, 20);
            this.to2.TabIndex = 31;
            // 
            // convert2
            // 
            this.convert2.AutoSize = true;
            this.convert2.Location = new System.Drawing.Point(278, 298);
            this.convert2.Name = "convert2";
            this.convert2.Size = new System.Drawing.Size(0, 13);
            this.convert2.TabIndex = 32;
            // 
            // convert3
            // 
            this.convert3.AutoSize = true;
            this.convert3.Location = new System.Drawing.Point(278, 324);
            this.convert3.Name = "convert3";
            this.convert3.Size = new System.Drawing.Size(0, 13);
            this.convert3.TabIndex = 33;
            // 
            // convert4
            // 
            this.convert4.AutoSize = true;
            this.convert4.Location = new System.Drawing.Point(278, 350);
            this.convert4.Name = "convert4";
            this.convert4.Size = new System.Drawing.Size(0, 13);
            this.convert4.TabIndex = 34;
            // 
            // convert5
            // 
            this.convert5.AutoSize = true;
            this.convert5.Location = new System.Drawing.Point(278, 376);
            this.convert5.Name = "convert5";
            this.convert5.Size = new System.Drawing.Size(0, 13);
            this.convert5.TabIndex = 35;
            // 
            // measurement2
            // 
            this.measurement2.AutoSize = true;
            this.measurement2.Location = new System.Drawing.Point(83, 298);
            this.measurement2.Name = "measurement2";
            this.measurement2.Size = new System.Drawing.Size(0, 13);
            this.measurement2.TabIndex = 36;
            // 
            // measurement3
            // 
            this.measurement3.AutoSize = true;
            this.measurement3.Location = new System.Drawing.Point(83, 324);
            this.measurement3.Name = "measurement3";
            this.measurement3.Size = new System.Drawing.Size(0, 13);
            this.measurement3.TabIndex = 37;
            // 
            // measurement4
            // 
            this.measurement4.AutoSize = true;
            this.measurement4.Location = new System.Drawing.Point(83, 350);
            this.measurement4.Name = "measurement4";
            this.measurement4.Size = new System.Drawing.Size(0, 13);
            this.measurement4.TabIndex = 38;
            // 
            // measurement5
            // 
            this.measurement5.AutoSize = true;
            this.measurement5.Location = new System.Drawing.Point(83, 376);
            this.measurement5.Name = "measurement5";
            this.measurement5.Size = new System.Drawing.Size(0, 13);
            this.measurement5.TabIndex = 39;
            // 
            // txt_Convert
            // 
            this.txt_Convert.Location = new System.Drawing.Point(209, 214);
            this.txt_Convert.Name = "txt_Convert";
            this.txt_Convert.ReadOnly = true;
            this.txt_Convert.Size = new System.Drawing.Size(63, 20);
            this.txt_Convert.TabIndex = 40;
            // 
            // unit
            // 
            this.unit.AutoSize = true;
            this.unit.Location = new System.Drawing.Point(278, 217);
            this.unit.Name = "unit";
            this.unit.Size = new System.Drawing.Size(0, 13);
            this.unit.TabIndex = 41;
            // 
            // convertsTo
            // 
            this.convertsTo.AutoSize = true;
            this.convertsTo.Location = new System.Drawing.Point(12, 217);
            this.convertsTo.Name = "convertsTo";
            this.convertsTo.Size = new System.Drawing.Size(0, 13);
            this.convertsTo.TabIndex = 42;
            // 
            // frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 483);
            this.Controls.Add(this.convertsTo);
            this.Controls.Add(this.unit);
            this.Controls.Add(this.txt_Convert);
            this.Controls.Add(this.measurement5);
            this.Controls.Add(this.measurement4);
            this.Controls.Add(this.measurement3);
            this.Controls.Add(this.measurement2);
            this.Controls.Add(this.convert5);
            this.Controls.Add(this.convert4);
            this.Controls.Add(this.convert3);
            this.Controls.Add(this.convert2);
            this.Controls.Add(this.to2);
            this.Controls.Add(this.to3);
            this.Controls.Add(this.to4);
            this.Controls.Add(this.to5);
            this.Controls.Add(this.convert1);
            this.Controls.Add(this.to1);
            this.Controls.Add(this.measurement1);
            this.Controls.Add(this.item2);
            this.Controls.Add(this.item3);
            this.Controls.Add(this.item4);
            this.Controls.Add(this.item5);
            this.Controls.Add(this.item1);
            this.Controls.Add(this.listStatus);
            this.Controls.Add(this.saved_txt);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.clear_btn);
            this.Controls.Add(this.btn_km_to_miles);
            this.Controls.Add(this.btn_cm_to_feet);
            this.Controls.Add(this.btn_cels_to_fahr);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_M_to_Feet);
            this.Controls.Add(this.btn_CM_to_Inches);
            this.Controls.Add(this.txt_UnitOfMeasure);
            this.Controls.Add(this.lbl_UofM);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frm_Main";
            this.Text = "ATCA Gas Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_UofM;
        private System.Windows.Forms.TextBox txt_UnitOfMeasure;
        private System.Windows.Forms.Button btn_CM_to_Inches;
        private System.Windows.Forms.Button btn_M_to_Feet;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_cels_to_fahr;
        private System.Windows.Forms.Button btn_cm_to_feet;
        private System.Windows.Forms.Button btn_km_to_miles;
        private System.Windows.Forms.Button clear_btn;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.Label saved_txt;
        private System.Windows.Forms.Label listStatus;
        private System.Windows.Forms.TextBox item1;
        private System.Windows.Forms.TextBox item5;
        private System.Windows.Forms.TextBox item4;
        private System.Windows.Forms.TextBox item3;
        private System.Windows.Forms.TextBox item2;
        private System.Windows.Forms.Label measurement1;
        private System.Windows.Forms.TextBox to1;
        private System.Windows.Forms.Label convert1;
        private System.Windows.Forms.TextBox to5;
        private System.Windows.Forms.TextBox to4;
        private System.Windows.Forms.TextBox to3;
        private System.Windows.Forms.TextBox to2;
        private System.Windows.Forms.Label convert2;
        private System.Windows.Forms.Label convert3;
        private System.Windows.Forms.Label convert4;
        private System.Windows.Forms.Label convert5;
        private System.Windows.Forms.Label measurement2;
        private System.Windows.Forms.Label measurement3;
        private System.Windows.Forms.Label measurement4;
        private System.Windows.Forms.Label measurement5;
        private System.Windows.Forms.TextBox txt_Convert;
        private System.Windows.Forms.Label unit;
        private System.Windows.Forms.Label convertsTo;
    }
}

