﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ConverterApp
// This program was written by Gail Mosdell
// It forms the base of a converter program for the OS-Assessment Two for Cert IV
// Date : February 2017
{
    public partial class frm_Main : Form
    {
        double[] variables = new double[5] {/*centimetres to inches*/ 0.3937,
            /*metres to feet*/ 3.2808,
            /*celsius to fahrenheit*/ 1.8 /* + 32 */,
            /*centimetres to feet*/ 0.03281,
            /*kilometres to miles*/ 0.62137 };

        public frm_Main()
        {
            InitializeComponent();
        }

        // Global Variables and Constants
        double dbl_UofM, dbl_Convert;
        public void save_btn_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
                {
                    MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                    txt_UnitOfMeasure.Clear();
                    txt_UnitOfMeasure.Focus();
                    txt_Convert.Clear();
                    convertsTo.Text = "";
                    unit.Text = "";
                }
                else if (item1.Text == "")
                {


                    item1.Text = txt_UnitOfMeasure.Text;
                    saved_txt.Text = "Saved!";


                    txt_UnitOfMeasure.Clear();
                    txt_Convert.Clear();
                }

                else if (item2.Text == "")
                {
                    item2.Text = txt_UnitOfMeasure.Text;
                    saved_txt.Text = "Saved!";


                    txt_UnitOfMeasure.Clear();
                    txt_Convert.Clear();
                }

                else if (item3.Text == "")
                {
                    item3.Text = txt_UnitOfMeasure.Text;
                    saved_txt.Text = "Saved!";


                    txt_UnitOfMeasure.Clear();
                    txt_Convert.Clear();
                }

                else if (item4.Text == "")
                {
                    item4.Text = txt_UnitOfMeasure.Text;
                    saved_txt.Text = "Saved!";


                    txt_UnitOfMeasure.Clear();
                    txt_Convert.Clear();
                }
                else if (item5.Text == "")
                {
                    item5.Text = txt_UnitOfMeasure.Text;
                    saved_txt.Text = "Saved!";


                    txt_UnitOfMeasure.Clear();
                    txt_Convert.Clear();
                }
                else
                {
                    listStatus.Text = "No more can be saved.";
                }
            }
     

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_CM_to_Inches_Click(object sender, EventArgs e)
        {
            saved_txt.Text = "";
            if (txt_UnitOfMeasure.Text == "")
            {
                if (item1.Text != "")
                {
                    double item1Convert = Convert.ToDouble(item1.Text);
                    to1.Text = Convert.ToString(item1Convert * variables[0]);
                    measurement1.Text = "centimetres converts to: ";
                    convert1.Text = " inches";

                    if (item2.Text != "")
                    {
                        double item2Convert = Convert.ToDouble(item2.Text);
                        to2.Text = Convert.ToString(item2Convert * variables[0]);
                        measurement2.Text = "centimetres converts to: ";
                        convert2.Text = " inches";

                        if (item3.Text != "")
                        {
                            double item3Convert = Convert.ToDouble(item3.Text);
                            to3.Text = Convert.ToString(item3Convert * variables[0]);
                            measurement3.Text = "centimetres converts to: ";
                            convert3.Text = " inches";

                            if (item4.Text != "")
                            {
                                double item4Convert = Convert.ToDouble(item4.Text);
                                to4.Text = Convert.ToString(item4Convert * variables[0]);
                                measurement4.Text = "centimetres converts to: ";
                                convert4.Text = " inches";

                                if (item5.Text != "")
                                {
                                    double item5Convert = Convert.ToDouble(item5.Text);
                                    to5.Text = Convert.ToString(item5Convert * variables[0]);
                                    measurement5.Text = "centimetres converts to: ";
                                    convert5.Text = " inches";
                                }
                            }
                        }
                    }
                }
            }
            else if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure.Clear();
                txt_UnitOfMeasure.Focus();
                txt_Convert.Clear();
                convertsTo.Text = "";
                unit.Text = "";
            }
            else
            {
                dbl_Convert = (dbl_UofM * variables[0]);
                txt_Convert.Text = dbl_Convert.ToString();
                convertsTo.Text = txt_UnitOfMeasure.Text + " centimetres is converted to ";
                unit.Text = " inches.";
            }
        }


        private void btn_cels_to_fahr_Click(object sender, EventArgs e)
        {
            saved_txt.Text = "";
            if (txt_UnitOfMeasure.Text == "")
            {
                if (item1.Text != "")
                {
                    double item1Convert = Convert.ToDouble(item1.Text);
                    to1.Text = Convert.ToString((item1Convert * variables[2]) + 32);
                    measurement1.Text = "celsius converts to: ";
                    convert1.Text = " fahrenheit";

                    if (item2.Text != "")
                    {
                        double item2Convert = Convert.ToDouble(item2.Text);
                        to2.Text = Convert.ToString((item2Convert * variables[2]) + 32);
                        measurement2.Text = "celsius converts to: ";
                        convert2.Text = " fahrenheit";

                        if (item3.Text != "")
                        {
                            double item3Convert = Convert.ToDouble(item3.Text);
                            to3.Text = Convert.ToString((item3Convert * variables[2]) + 32);
                            measurement3.Text = "celsius converts to: ";
                            convert3.Text = " fahrenheit";

                            if (item4.Text != "")
                            {
                                double item4Convert = Convert.ToDouble(item4.Text);
                                to4.Text = Convert.ToString((item4Convert * variables[2]) + 32);
                                measurement4.Text = "celsius converts to: ";
                                convert4.Text = " fahrenheit";

                                if (item5.Text != "")
                                {
                                    double item5Convert = Convert.ToDouble(item5.Text);
                                    to5.Text = Convert.ToString((item5Convert * variables[2]) + 32);
                                    measurement5.Text = "celsius converts to: ";
                                    convert5.Text = " fahrenheit";
                                }
                            }
                        }
                    }
                }
            }
            else if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure.Clear();
                txt_UnitOfMeasure.Focus();
                txt_Convert.Clear();
                convertsTo.Text = "";
                unit.Text = "";


            }
            else
            {
                dbl_Convert = (dbl_UofM * variables[2]) + 32;
                txt_Convert.Text = dbl_Convert.ToString();
                convertsTo.Text = txt_UnitOfMeasure.Text + " celsius is converted to ";
                unit.Text = " fahrenheit.";
            }
        }

        private void btn_cm_to_feet_Click(object sender, EventArgs e)
        {

            saved_txt.Text = "";
            if (txt_UnitOfMeasure.Text == "")
            {
                if (item1.Text != "")
                {
                    double item1Convert = Convert.ToDouble(item1.Text);
                    to1.Text = Convert.ToString(item1Convert * variables[3]);
                    measurement1.Text = "centimetres converts to: ";
                    convert1.Text = " feet";

                    if (item2.Text != "")
                    {
                        double item2Convert = Convert.ToDouble(item2.Text);
                        to2.Text = Convert.ToString(item2Convert * variables[3]);
                        measurement2.Text = "centimetres converts to: ";
                        convert2.Text = " feet";

                        if (item3.Text != "")
                        {
                            double item3Convert = Convert.ToDouble(item3.Text);
                            to3.Text = Convert.ToString(item3Convert * variables[3]);
                            measurement3.Text = "centimetres converts to: ";
                            convert3.Text = " feet";

                            if (item4.Text != "")
                            {
                                double item4Convert = Convert.ToDouble(item4.Text);
                                to4.Text = Convert.ToString(item4Convert * variables[3]);
                                measurement4.Text = "centimetres converts to: ";
                                convert4.Text = " feet";

                                if (item5.Text != "")
                                {
                                    double item5Convert = Convert.ToDouble(item5.Text);
                                    to5.Text = Convert.ToString(item5Convert * variables[3]);
                                    measurement5.Text = "centimetres converts to: ";
                                    convert5.Text = " feet";
                                }
                            }
                        }
                    }
                }
            }
            else if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure.Clear();
                txt_UnitOfMeasure.Focus();
                txt_Convert.Clear();
                convertsTo.Text = "";
                unit.Text = "";
            }
            else
            {
                dbl_Convert = dbl_UofM * variables[3];
                txt_Convert.Text = dbl_Convert.ToString();
                convertsTo.Text = txt_UnitOfMeasure.Text + " centimetres is converted to ";
                unit.Text = " feet.";
            }
        }

        private void btn_km_to_miles_Click(object sender, EventArgs e)
        {

            saved_txt.Text = "";
            if (txt_UnitOfMeasure.Text == "")
            {
                if (item1.Text != "")
                {
                    double item1Convert = Convert.ToDouble(item1.Text);
                    to1.Text = Convert.ToString(item1Convert * variables[4]);
                    measurement1.Text = "kilometres converts to: ";
                    convert1.Text = " miles";

                    if (item2.Text != "")
                    {
                        double item2Convert = Convert.ToDouble(item2.Text);
                        to2.Text = Convert.ToString(item2Convert * variables[4]);
                        measurement2.Text = "kilometres converts to: ";
                        convert2.Text = " miles";

                        if (item3.Text != "")
                        {
                            double item3Convert = Convert.ToDouble(item3.Text);
                            to3.Text = Convert.ToString(item3Convert * variables[4]);
                            measurement3.Text = "kilometres converts to: ";
                            convert3.Text = " miles";

                            if (item4.Text != "")
                            {
                                double item4Convert = Convert.ToDouble(item4.Text);
                                to4.Text = Convert.ToString(item4Convert * variables[4]);
                                measurement4.Text = "kilometres converts to: ";
                                convert4.Text = " miles";

                                if (item5.Text != "")
                                {
                                    double item5Convert = Convert.ToDouble(item5.Text);
                                    to5.Text = Convert.ToString(item5Convert * variables[4]);
                                    measurement5.Text = "kilometres converts to: ";
                                    convert5.Text = " miles";
                                }
                            }
                        }
                    }
                }
            }
            else if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure.Clear();
                txt_UnitOfMeasure.Focus();
                txt_Convert.Clear();
                convertsTo.Text = "";
                unit.Text = "";
            }
            else
            {
                dbl_Convert = dbl_UofM * variables[4];
                txt_Convert.Text = dbl_Convert.ToString();
                convertsTo.Text = txt_UnitOfMeasure.Text + " kilometres is converted to ";
                unit.Text = " miles.";
            }
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            item1.Clear();
            item2.Clear();
            item3.Clear();
            item4.Clear();
            item5.Clear();
            to1.Clear();
            to2.Clear();
            to3.Clear();
            to4.Clear();
            to5.Clear();
            txt_UnitOfMeasure.Clear();
            txt_Convert.Clear();
            saved_txt.Text = "";
            convertsTo.Text = "";
            unit.Text = "";
            measurement1.Text = "";
            measurement2.Text = "";
            measurement3.Text = "";
            measurement4.Text = "";
            measurement5.Text = "";
            convert1.Text = "";
            convert2.Text = "";
            convert3.Text = "";
            convert4.Text = "";
            convert5.Text = "";
        }


        private void btn_M_to_Feet_Click(object sender, EventArgs e)
        {

            saved_txt.Text = "";
            if (txt_UnitOfMeasure.Text == "")
            {
                if (item1.Text != "")
                {
                    double item1Convert = Convert.ToDouble(item1.Text);
                    to1.Text = Convert.ToString(item1Convert * variables[1]);
                    measurement1.Text = "metres converts to: ";
                    convert1.Text = " feet";

                    if (item2.Text != "")
                    {
                        double item2Convert = Convert.ToDouble(item2.Text);
                        to2.Text = Convert.ToString(item2Convert * variables[1]);
                        measurement2.Text = "metres converts to: ";
                        convert2.Text = " feet";

                        if (item3.Text != "")
                        {
                            double item3Convert = Convert.ToDouble(item3.Text);
                            to3.Text = Convert.ToString(item3Convert * variables[1]);
                            measurement3.Text = "metres converts to: ";
                            convert3.Text = " feet";

                            if (item4.Text != "")
                            {
                                double item4Convert = Convert.ToDouble(item4.Text);
                                to4.Text = Convert.ToString(item4Convert * variables[1]);
                                measurement4.Text = "metres converts to: ";
                                convert4.Text = " feet";

                                if (item5.Text != "")
                                {
                                    double item5Convert = Convert.ToDouble(item5.Text);
                                    to5.Text = Convert.ToString(item5Convert * variables[1]);
                                    measurement5.Text = "metres converts to: ";
                                    convert5.Text = " feet";
                                }
                            }
                        }
                    }
                }
            }
            else if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure.Clear();
                txt_UnitOfMeasure.Focus();
                txt_Convert.Clear();
                convertsTo.Text = "";
                unit.Text = "";
            }
            else
            {
                dbl_Convert = dbl_UofM * variables[1];
                txt_Convert.Text = dbl_Convert.ToString();
                convertsTo.Text = txt_UnitOfMeasure.Text + " metres is converted to ";
                unit.Text = " feet.";
            }
        }
    }
}
